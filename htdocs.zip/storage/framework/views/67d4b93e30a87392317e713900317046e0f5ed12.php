<?php $__env->startSection('content'); ?>
<div class="row" style="margin-left: 0px; margin-right:0px;">
    <div class="col-lg-6 d-flex justify-content-center align-items-center py-5"  style="margin-left: 0px; margin-right:0px;">
        <form class="row justify-content-center align-items-center" method="POST" action="<?php echo e(route('home')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center align-items-center">
                <div class="col-10 col-sm-9 col-md-8 col-lg-7">
                    <p class="f4">Please login with your Member ID and Password provided in your welcome email.</p>
                </div>
            </div>
            <div class="row justify-content-center align-items-center">
                <div class="col-10 col-sm-9 col-md-8 col-lg-7">
                    <div class="fm-group">
                        <label class="fm-label text-start" for="memberid">Member ID</label>
                        <input id="memberid" type="text" class="fm-input <?php $__errorArgs = ['memberid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Member ID" name="memberid" value="<?php echo e(old('memberid')); ?>" required autocomplete="memberid" autofocus>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center align-items-center">
                <div class="col-10 col-sm-9 col-md-8 col-lg-7">
                    <div class="fm-group">
                        <label class="fm-label text-start" for="password">Password</label>
                        <input id="password" type="password" class="fm-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center align-items-center">
                <button type="submit" class="col-10 col-sm-9 col-md-8 col-lg-7 btn btn-secondary" style="font-size: 24px;">log in</button>
            </div>
        </form>
    </div>
    <div class="col-lg-6"  style="margin-left: 0px; margin-right:0px;">
        <img style="width: 100%; height: 100vh" src="<?php echo e(asset('img/background.jpg')); ?>">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP7\htdocs\resources\views/welcome.blade.php ENDPATH**/ ?>